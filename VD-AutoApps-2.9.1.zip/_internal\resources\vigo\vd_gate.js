// VD Auto Apps: opens the factory signature gate (DftcCheckValidCertImpl) of the
// Vigo / Evolute i-Joy 2G / Nammi 06 head unit while our injector runs.
//
// Injected into system_server by frida (RAM-only, one-shot): every boolean checkCert()
// overload answers true, so sideloaded APKs pass the factory "DF apk cert incorrect"
// check. Stopping the injector reverts the hook; a full reboot clears everything.
//
// Adapted from the studied dealer kit's system_server.js, stripped down to this one
// job. ASCII only; the readiness marker this program polls for is "[VD-GATE] ready".

console.log("[VD-GATE] script loaded (frida " + Frida.version + ", pid " + Process.id + ")");

Java.perform(function () {
    var TARGET = "com.dftc.server.pm.DftcCheckValidCertImpl";
    var POLL_MS = 1500;
    var MAX_TRIES = 40;   // ~60 s: in system_server the class is usually loaded at once
    var TAG = "[VD-GATE] ";

    var hooked = false;
    var attempts = 0;
    var okLogAt = 0;

    function primToFrida(c) {
        return c.isPrimitive()
            ? ({ boolean: "boolean", byte: "byte", char: "char", short: "short",
                 int: "int", long: "long", float: "float", double: "double",
                 void: "void" }[c.getName()] || c.getName())
            : c.getName();
    }

    function attachHooks(Cls) {
        var checkCert = Cls.checkCert;
        var methods = Cls.class.getDeclaredMethods();
        var n = 0;
        for (var i = 0; i < methods.length; i++) {
            var m = methods[i];
            if (m.getName() !== "checkCert") continue;
            if (m.getReturnType().getName() !== "boolean") continue;
            var pts = m.getParameterTypes();
            var fridaArgs = [];
            for (var p = 0; p < pts.length; p++) fridaArgs.push(primToFrida(pts[p]));
            try {
                (function (sig) {
                    checkCert.overload.apply(checkCert, fridaArgs).implementation = function () {
                        var t = Date.now();
                        if (t - okLogAt > 20000) {
                            okLogAt = t;
                            console.log(TAG + "checkCert ok (throttled 20s)");
                        }
                        return true;
                    };
                })("(" + fridaArgs.join(",") + ")");
                n++;
            } catch (e) {
                console.log(TAG + "attach failed: " + e);
            }
        }
        if (n === 0) {
            // the signature reconstruction failed for every overload: fall back to all
            // BOOLEAN ones (forcing true into a non-boolean overload would be a type error)
            checkCert.overloads.forEach(function (ov) {
                // ov.returnType is a Type object (.className), not a bare string - compare
                // defensively so the fallback actually matches the boolean overloads.
                var rt = ov.returnType && (ov.returnType.className || ov.returnType);
                if (rt !== "boolean") return;
                ov.implementation = function () { return true; };
                n++;
            });
        }
        if (n > 0) {
            console.log("[VD-GATE] ready: " + n);
            hooked = true;
        } else {
            // the class is there but nothing could be hooked - retrying will not help;
            // the failure marker is what the program's poller treats as the dead end
            console.log("[VD-GATE] failed: no boolean checkCert overloads");
            hooked = true;
        }
    }

    function tryHook() {
        if (hooked) return;
        attempts++;
        Java.enumerateClassLoaders({
            onMatch: function (loader) {
                if (hooked) return;
                try {
                    loader.findClass(TARGET);
                    Java.classFactory.loader = loader;
                    attachHooks(Java.use(TARGET));
                } catch (_) {}
            },
            onComplete: function () {
                if (!hooked && attempts % 8 === 1)
                    console.log(TAG + "waiting for loader... (" + attempts + "/" + MAX_TRIES + ")");
            }
        });
    }

    tryHook();
    if (!hooked) {
        var id = setInterval(function () {
            tryHook();
            if (hooked || attempts >= MAX_TRIES) {
                clearInterval(id);
                if (!hooked) console.log("[VD-GATE] failed: class not found after " + attempts + " tries");
            }
        }, POLL_MS);
    }
});
