#!/system/bin/sh
# VD Auto Apps (DF Mage): re-injector for frida hooks.
# The hook set comes from hooks.conf ("pkg:script[:extra]" lines, '#' comments),
# and all paths live under /data/local/tmp/vd.
# Modes: (no arg) run the re-inject loop | stop | status | reset.
#
# Source of truth: resources/df-mage/kit in the program's repository (shipped inside
# the program, NOT with the Drive kit) - the safety logic below must not be replaced
# by an older copy from a kit sync.
#
# Fuse (crash-loop breaker): a hooked process that dies soon after an injection counts
# as a crash. FUSE_MAX such crashes within FUSE_WINDOW_SEC (system_server: FUSE_MAX_SYSTEM -
# it never restarts on its own, every restart is a soft reboot of Android) trip the fuse
# for that target: it is left alone until the operator re-deploys the hooks (the program
# runs `reset`) or runs `reset` by hand. A full reboot of the unit is never counted (the
# kernel boot_id changes).

FRIDA="${FRIDA:-/data/local/tmp/vd/frida}"
SCRIPT_DIR="${SCRIPT_DIR:-/data/local/tmp/vd/files}"
STATE_DIR="${STATE_DIR:-/data/local/tmp/vd/files/autostart}"
LOG_DIR="${LOG_DIR:-/data/local/tmp/vd/files}"
CONF="$SCRIPT_DIR/hooks.conf"
LOOP_SLEEP="${LOOP_SLEEP:-2}"
INJECT_SETTLE_SEC="${INJECT_SETTLE_SEC:-4}"
REINJECT_AFTER_TERM_SEC="${REINJECT_AFTER_TERM_SEC:-5}"
FUSE_WINDOW_SEC="${FUSE_WINDOW_SEC:-900}"
FUSE_SHORT_LIFE_SEC="${FUSE_SHORT_LIFE_SEC:-180}"
FUSE_MAX="${FUSE_MAX:-3}"
FUSE_MAX_SYSTEM="${FUSE_MAX_SYSTEM:-2}"
# a freshly (re)started target is left to settle before frida touches it
TARGET_MIN_AGE_SEC="${TARGET_MIN_AGE_SEC:-20}"
BOOT_ID_FILE="${BOOT_ID_FILE:-/proc/sys/kernel/random/boot_id}"
LOAD_LOCK="$STATE_DIR/vd_load.lock"

logs() {
    log -p i -t VDLOAD "$1" 2>/dev/null || echo "VDLOAD: $1"
}

# `status` is READ BY THE PC: `adb shell` captures stdout only, while logs() writes to
# logcat (where `log` exists, i.e. always on this firmware) and so never reaches the
# caller. Every line the program parses must go through say(), not logs().
say() {
    echo "$1"
    log -p i -t VDLOAD "$1" 2>/dev/null || true
}

first_pid() {
    echo "$1" | tr -d '\r\n\t' | awk '{print $1}' | tr -cd '0-9'
}

proc_alive() {
    pid="$1"
    case "$pid" in
        '' | *[!0-9]*) return 1 ;;
    esac
    [ -d "/proc/$pid" ]
}

# pidof on Mage after reboot often returns a dead PID - check /proc, else ps.
# A PID may also be REUSED by another process, so /proc/<pid>/comm must match
# the package: comm is kernel-clipped to 15 chars, clipped from the FRONT for
# long Android package names, so comm is either a prefix or a suffix of pkg.
pid_matches_pkg() {
    pid="$1"
    pkg="$2"
    comm="$(cat "/proc/$pid/comm" 2>/dev/null)"
    [ -n "$comm" ] || return 1
    case "$pkg" in
        "$comm") return 0 ;;
    esac
    case "$pkg" in
        *"$comm") return 0 ;;
        "$comm"*) return 0 ;;
    esac
    return 1
}

find_pkg_pid() {
    pkg="$1"
    pid=""
    for candidate in $(pidof "$pkg" 2>/dev/null); do
        candidate="$(first_pid "$candidate")"
        if proc_alive "$candidate" && pid_matches_pkg "$candidate" "$pkg"; then
            pid="$candidate"
            break
        fi
    done
    if [ -z "$pid" ]; then
        pid="$(ps -ef 2>/dev/null | grep -v grep | awk -v pkg="$pkg" '
            $NF == pkg { print $2; exit }
        ')"
        pid="$(first_pid "$pid")"
    fi
    if proc_alive "$pid" && pid_matches_pkg "$pid" "$pkg"; then
        echo "$pid"
    fi
}

now_sec() {
    date +%s 2>/dev/null || echo 0
}

# Stable short name for state files: clip the package to alnum + '_'.
short_name() {
    echo "$1" | tr -c '[:alnum:]' '_'
}

frida_pid_file() {
    echo "$STATE_DIR/$(short_name "$1").frida.pid"
}

target_pid_file() {
    echo "$STATE_DIR/$(short_name "$1").target.pid"
}

reinject_after_file() {
    echo "$STATE_DIR/$(short_name "$1").reinject_after"
}

log_file_for_pkg() {
    echo "$LOG_DIR/load_$(short_name "$1").txt"
}

attached_at_file() {
    echo "$STATE_DIR/$(short_name "$1").attached_at"
}

crashes_file() {
    echo "$STATE_DIR/$(short_name "$1").crashes"
}

tripped_file() {
    echo "$STATE_DIR/$(short_name "$1").tripped"
}

boot_id() {
    tr -d ' \r\n' <"$BOOT_ID_FILE" 2>/dev/null
}

# SELinux goes permissive only right before frida needs it (ptrace of system
# processes), never at boot or for stop/status: a unit whose hooks are all fused or
# not configured stays enforcing.
ensure_permissive() {
    [ "$(getenforce 2>/dev/null)" = "Permissive" ] && return 0
    /system/xbin/su 0 setenforce 0 2>/dev/null || setenforce 0 2>/dev/null || true
}

is_tripped() {
    [ -f "$(tripped_file "$1")" ]
}

# Seconds since the process started (age of its /proc entry); empty = unknown.
target_age() {
    started="$(stat -c %Y "/proc/$1" 2>/dev/null)"
    case "$started" in
        '' | *[!0-9]*) return 0 ;;
    esac
    echo $(( $(now_sec) - started ))
}

# The target we were attached to is gone (died or restarted). If it died soon after
# our injection in this same boot, count a crash; enough crashes trip the fuse.
note_target_gone() {
    pkg="$1"
    af="$(attached_at_file "$pkg")"
    [ -f "$af" ] || return 0
    at="$(awk '{print $1}' "$af" 2>/dev/null)"
    at_boot="$(awk '{print $2}' "$af" 2>/dev/null)"
    rm -f "$af" 2>/dev/null || true
    case "$at" in
        '' | *[!0-9]*) return 0 ;;
    esac
    [ "$at_boot" = "$(boot_id)" ] || return 0          # a full reboot is not a crash
    now="$(now_sec)"
    [ $((now - at)) -lt "$FUSE_SHORT_LIFE_SEC" ] || return 0
    cf="$(crashes_file "$pkg")"
    {
        [ -f "$cf" ] && awk -v lim=$((now - FUSE_WINDOW_SEC)) '$1 >= lim' "$cf" 2>/dev/null
        echo "$now"
    } >"$cf.new" 2>/dev/null && mv "$cf.new" "$cf" 2>/dev/null
    n="$(wc -l <"$cf" 2>/dev/null | tr -cd '0-9')"
    max="$FUSE_MAX"
    [ "$pkg" = "system_server" ] && max="$FUSE_MAX_SYSTEM"
    logs "Crash after inject: $pkg ($n in ${FUSE_WINDOW_SEC}s, fuse at $max)"
    if [ "${n:-0}" -ge "$max" ]; then
        echo "$n crashes within ${FUSE_WINDOW_SEC}s after injection" >"$(tripped_file "$pkg")" 2>/dev/null
        logs "FUSE TRIPPED: $pkg left alone until the hooks are re-deployed (vd_load.sh reset)"
    fi
}

our_frida_pids() {
    for fpid in $(pidof frida 2>/dev/null); do
        case "$fpid" in
            '' | *[!0-9]*) continue ;;
        esac
        cl="$(tr '\0' ' ' <"/proc/$fpid/cmdline" 2>/dev/null)"
        case "$cl" in
            *"/data/local/tmp/vd/frida"*) echo "$fpid" ;;
        esac
    done
}

find_frida_pid_for_target() {
    target_pid="$1"
    for fpid in $(our_frida_pids); do
        cl="$(tr '\0' ' ' <"/proc/$fpid/cmdline" 2>/dev/null)"
        case "$cl" in
            *" -p $target_pid "* | *" -p $target_pid")
                echo "$fpid"
                return 0
                ;;
        esac
    done
}

frida_attached_to_target() {
    target_pid="$1"
    proc_alive "$target_pid" || return 1
    frida_pid="$(find_frida_pid_for_target "$target_pid")"
    [ -n "$frida_pid" ] && proc_alive "$frida_pid"
}

reinject_blocked_until() {
    pkg="$1"
    target_pid="$2"
    f="$(reinject_after_file "$pkg")"
    [ ! -f "$f" ] && return 1
    old_target=""
    [ -f "$(target_pid_file "$pkg")" ] && old_target="$(cat "$(target_pid_file "$pkg")" 2>/dev/null)"
    # the target process restarted - the cooldown must not hold it back
    if [ -n "$target_pid" ] && [ "$old_target" != "$target_pid" ]; then
        return 1
    fi
    until="$(cat "$f" 2>/dev/null)"
    now="$(now_sec)"
    [ -n "$until" ] && [ "$now" -lt "$until" ] 2>/dev/null
}

mark_reinject_cooldown() {
    pkg="$1"
    now="$(now_sec)"
    echo $((now + REINJECT_AFTER_TERM_SEC)) >"$(reinject_after_file "$pkg")" 2>/dev/null || true
}

clear_reinject_cooldown() {
    pkg="$1"
    rm -f "$(reinject_after_file "$pkg")" 2>/dev/null || true
}

stop_frida_pid() {
    pid="$1"
    proc_alive "$pid" || return 0
    kill -9 "$pid" 2>/dev/null || true
}

stop_frida_for_target() {
    target_pid="$1"
    frida_pid="$(find_frida_pid_for_target "$target_pid")"
    stop_frida_pid "$frida_pid"
}

stop_old_frida_for_pkg() {
    pkg="$1"
    target_pid="$(find_pkg_pid "$pkg")"
    if [ -n "$target_pid" ]; then
        stop_frida_for_target "$target_pid"
    fi
    f="$(frida_pid_file "$pkg")"
    if [ -f "$f" ]; then
        stop_frida_pid "$(cat "$f" 2>/dev/null)"
        rm -f "$f" 2>/dev/null || true
    fi
    tf="$(target_pid_file "$pkg")"
    if [ -f "$tf" ]; then
        stop_frida_for_target "$(cat "$tf" 2>/dev/null)"
    fi
}

# Kill frida sessions whose target process is already dead (orphans).
cleanup_stale_frida() {
    for fpid in $(our_frida_pids); do
        cl="$(tr '\0' ' ' <"/proc/$fpid/cmdline" 2>/dev/null)"
        tp="${cl#* -p }"
        tp="${tp%% *}"
        case "$tp" in
            '' | *[!0-9]*) continue ;;
        esac
        if ! proc_alive "$tp"; then
            stop_frida_pid "$fpid"
            logs "Stale frida $fpid dead target $tp"
        fi
    done
}

inject_failed_recently() {
    pkg="$1"
    logf="$(log_file_for_pkg "$pkg")"
    [ -f "$logf" ] || return 1
    tail -n 2 "$logf" 2>/dev/null | grep -q "Process terminated"
}

start_inject_for_pkg() {
    pkg="$1"
    target_pid="$2"
    script="$3"
    extra="$4"
    out="$(log_file_for_pkg "$pkg")"

    if ! proc_alive "$target_pid"; then
        logs "Skip inject $pkg: pid=$target_pid not alive"
        rm -f "$(target_pid_file "$pkg")" 2>/dev/null || true
        return 1
    fi

    ensure_permissive
    logs "Injecting $pkg pid=$target_pid script=$(basename "$script")"
    if [ -n "$extra" ] && [ -f "$SCRIPT_DIR/$extra" ]; then
        logs "  + $extra"
        "$FRIDA" -p "$target_pid" -s "$SCRIPT_DIR/$script" -s "$SCRIPT_DIR/$extra" >>"$out" 2>&1 &
    else
        "$FRIDA" -p "$target_pid" -s "$SCRIPT_DIR/$script" >>"$out" 2>&1 &
    fi
    sleep "$INJECT_SETTLE_SEC"

    frida_pid="$(find_frida_pid_for_target "$target_pid")"
    if [ -z "$frida_pid" ]; then
        logs "Inject $pkg pid=$target_pid: not attached after ${INJECT_SETTLE_SEC}s"
        if inject_failed_recently "$pkg"; then
            mark_reinject_cooldown "$pkg"
        fi
        return 1
    fi

    echo "$frida_pid" >"$(frida_pid_file "$pkg")" 2>/dev/null || true
    echo "$target_pid" >"$(target_pid_file "$pkg")" 2>/dev/null || true
    echo "$(now_sec) $(boot_id)" >"$(attached_at_file "$pkg")" 2>/dev/null || true
    clear_reinject_cooldown "$pkg"
    logs "Attached $pkg target=$target_pid frida=$frida_pid"
    return 0
}

ensure_injected_pkg() {
    pkg="$1"
    script="$2"
    extra="$3"

    [ -n "$pkg" ] && [ -n "$script" ] || return 0
    [ -f "$SCRIPT_DIR/$script" ] || { logs "Skip $pkg: $script not found"; return 0; }
    if [ -n "$extra" ] && [ ! -f "$SCRIPT_DIR/$extra" ]; then
        logs "Note $pkg: extra $extra not found, main script only"
        extra=""
    fi

    is_tripped "$pkg" && return 0

    target_pid="$(find_pkg_pid "$pkg")"
    old_target=""
    [ -f "$(target_pid_file "$pkg")" ] && old_target="$(cat "$(target_pid_file "$pkg")" 2>/dev/null)"

    if [ -n "$old_target" ] && [ "$old_target" != "$target_pid" ]; then
        note_target_gone "$pkg"   # the process we hooked died or restarted
    fi
    if [ -z "$target_pid" ] || is_tripped "$pkg"; then
        stop_old_frida_for_pkg "$pkg"
        rm -f "$(target_pid_file "$pkg")" 2>/dev/null || true
        return 0
    fi

    if reinject_blocked_until "$pkg" "$target_pid"; then
        return 0
    fi

    need_inject=0
    if [ "$old_target" != "$target_pid" ]; then
        need_inject=1
    elif ! frida_attached_to_target "$target_pid"; then
        need_inject=1
    fi

    if [ "$need_inject" -eq 0 ]; then
        frida_pid="$(find_frida_pid_for_target "$target_pid")"
        echo "$frida_pid" >"$(frida_pid_file "$pkg")" 2>/dev/null || true
        return 0
    fi

    # let a freshly (re)started target settle first; system_server also waits for the boot
    if [ "$pkg" = "system_server" ] && [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; then
        return 0
    fi
    age="$(target_age "$target_pid")"
    if [ -n "$age" ] && [ "$age" -lt "$TARGET_MIN_AGE_SEC" ] 2>/dev/null; then
        return 0
    fi

    stop_old_frida_for_pkg "$pkg"
    start_inject_for_pkg "$pkg" "$target_pid" "$script" "$extra"
}

do_stop() {
    old="$(tr -cd '0-9' <"$LOAD_LOCK/pid" 2>/dev/null)"
    if [ -n "$old" ] && proc_alive "$old"; then
        kill "$old" 2>/dev/null || true
        logs "stopped supervisor pid=$old"
    fi
    for fpid in $(our_frida_pids); do
        stop_frida_pid "$fpid"
        logs "stopped frida $fpid"
    done
    rm -rf "$LOAD_LOCK" 2>/dev/null || true
}

do_status() {
    n=0
    for f in "$STATE_DIR"/*.target.pid; do
        [ -f "$f" ] || continue
        pkg="$(basename "$f" .target.pid)"
        tp="$(cat "$f" 2>/dev/null)"
        fp="$(cat "$STATE_DIR/$pkg.frida.pid" 2>/dev/null)"
        if proc_alive "$tp" && proc_alive "$fp"; then
            say "attached: $pkg target=$tp frida=$fp"
            n=$((n + 1))
        fi
    done
    for f in "$STATE_DIR"/*.tripped; do
        [ -f "$f" ] || continue
        say "tripped: $(basename "$f" .tripped) $(head -n 1 "$f" 2>/dev/null)"
    done
    if [ -f "$STATE_DIR/boot_safe_mode" ]; then
        say "safe-mode: $(head -n 1 "$STATE_DIR/boot_safe_mode" 2>/dev/null)"
    fi
    say "status: $n hook target(s) attached, frida pids: $(our_frida_pids | tr '\n' ' ')"
}

# The operator's explicit "try again": clears every fuse and the boot safe mode.
do_reset() {
    rm -f "$STATE_DIR"/*.tripped "$STATE_DIR"/*.crashes "$STATE_DIR"/*.attached_at \
          "$STATE_DIR/boot_safe_mode" "$STATE_DIR/boot_abnormal" 2>/dev/null || true
    logs "fuses and boot safe mode reset"
    say "reset: ok"
}

mkdir -p "$STATE_DIR" 2>/dev/null || true

if [ "$1" = "stop" ]; then
    do_stop
    exit 0
fi
if [ "$1" = "status" ]; then
    do_status
    exit 0
fi
if [ "$1" = "reset" ]; then
    do_reset
    exit 0
fi

if mkdir "$LOAD_LOCK" 2>/dev/null; then
    echo "$$" >"$LOAD_LOCK/pid" 2>/dev/null || true
else
    old_load="$(tr -cd '0-9' <"$LOAD_LOCK/pid" 2>/dev/null)"
    if [ -n "$old_load" ] && [ -d "/proc/$old_load" ] && [ "$old_load" != "$$" ]; then
        old_cmd="$(tr '\0' ' ' <"/proc/$old_load/cmdline" 2>/dev/null)"
        case "$old_cmd" in
            *vd_load.sh*)
                logs "vd_load already running pid=$old_load, exit"
                exit 0
                ;;
        esac
    fi
    rm -rf "$LOAD_LOCK" 2>/dev/null || true
    mkdir "$LOAD_LOCK" 2>/dev/null || true
    echo "$$" >"$LOAD_LOCK/pid" 2>/dev/null || true
fi
trap 'rm -rf "$LOAD_LOCK" 2>/dev/null' INT TERM

logs "VD hook loop started: conf=$CONF sleep=${LOOP_SLEEP}s"
while true; do
    if [ ! -f "$FRIDA" ]; then
        # a tweak-only deploy (DNS) has no frida at all: idle quietly, no log spam
        [ -n "$frida_missing_logged" ] || logs "Frida not found: $FRIDA (no frida hooks deployed)"
        frida_missing_logged=1
        sleep 60
        continue
    fi
    frida_missing_logged=""

    cleanup_stale_frida

    # hooks.conf is re-read every pass: a new deploy applies without a restart.
    if [ -f "$CONF" ]; then
        while IFS= read -r line || [ -n "$line" ]; do
            line="$(echo "$line" | tr -d '\r' | sed 's/#.*//' | awk '{$1=$1};1')"
            [ -n "$line" ] || continue
            pkg="${line%%:*}"
            rest="${line#*:}"
            [ "$rest" != "$line" ] || continue
            script="${rest%%:*}"
            extra=""
            case "$rest" in
                *:*) extra="${rest#*:}" ;;
            esac
            ensure_injected_pkg "$pkg" "$script" "$extra"
        done <"$CONF"
    fi

    sleep "$LOOP_SLEEP"
done
