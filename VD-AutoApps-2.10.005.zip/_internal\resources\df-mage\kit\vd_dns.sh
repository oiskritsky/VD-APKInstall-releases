#!/system/bin/sh
# VD net daemon (DF Mage): enable/reconnect WiFi, public DNS, policy routes.
# WiFi reconnect creates a new netId with an empty table - apps then fail
# with INTERNAL_ERROR / unknown host. Hidden SSIDs also skip autojoin.
# "once" = apply and exit. Default = stay up and reapply.
#
# Source of truth: resources/df-mage/kit in the program's repository.
# Network only: it no longer disables the factory voice service - handing the cabin mic
# to the assistant is a separate, explicit tweak ("voice") applied by the program.
# It needs root network rights (iptables / ip rule / ndc): when started by init in the
# shell domain it re-runs itself through su instead of switching SELinux to permissive
# for the whole system.

case "$(cat /proc/self/attr/current 2>/dev/null)" in
  *:su:*) ;;
  *)
    if [ -z "$VD_DNS_SU" ] && [ -x /system/xbin/su ]; then
      export VD_DNS_SU=1
      exec /system/xbin/su 0 /system/bin/sh "$0" "$@"
    fi
    ;;
esac

# The program writes this marker only when the DNS tweak is selected; the boot rc starts
# the daemon on every boot, and without the marker it has nothing to do.
[ -f /data/local/tmp/vd/files/dns.on ] || exit 0

DNS1="8.8.8.8"
DNS2="1.1.1.1"
LOG="/data/local/tmp/vd/files/vd_dns.log"
LOCK_DIR="/data/local/tmp/vd_dns.lock"
NID_LO=100
NID_HI=120
LAST_STATE=""

logd() {
  echo "$(date '+%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null || true
}

wlan_has_ip() {
  ip -o -4 addr show dev wlan0 2>/dev/null | grep -q " inet "
}

wpa_reconnect() {
  for sock in \
    /data/misc/wifi/sockets \
    /data/vendor/wifi/wpa/sockets \
    /data/vendor/wifi/wpa \
    /data/misc/wifi/wpa/sockets
  do
    [ -e "$sock" ] || continue
    wpa_cli -p "$sock" -i wlan0 enable_network all >/dev/null 2>&1 || true
    wpa_cli -p "$sock" -i wlan0 reconnect >/dev/null 2>&1 || true
    wpa_cli -p "$sock" -i wlan0 reassociate >/dev/null 2>&1 || true
  done
  wpa_cli -i wlan0 enable_network all >/dev/null 2>&1 || true
  wpa_cli -i wlan0 reconnect >/dev/null 2>&1 || true
  wpa_cli -i wlan0 reassociate >/dev/null 2>&1 || true
}

# Settings writes start a Java process each (`settings` is app_process) - they run on
# the first pass and then every SETTINGS_EVERY passes, not every 3 seconds.
SETTINGS_EVERY=100
PASS=0
LAST_GW=""
LAST_DEF=""

ensure_wifi() {
  if [ $((PASS % SETTINGS_EVERY)) -eq 0 ]; then
    /system/bin/settings put global wifi_on 1 >/dev/null 2>&1
    /system/bin/settings put global wifi_scan_always_enabled 1 >/dev/null 2>&1
  fi

  if wlan_has_ip; then
    return 0
  fi

  svc wifi enable >/dev/null 2>&1 || true
  cmd wifi set-wifi-enabled enabled >/dev/null 2>&1 || true
  cmd wifi start-scan >/dev/null 2>&1 || true
  wpa_reconnect
  return 0
}

# `ip rule add` does not deduplicate: re-adding every pass grew the rule list by
# 2 x 21 entries every 3 seconds. Delete-then-add keeps exactly one of each.
set_rule() {
  ip rule del "$@" 2>/dev/null
  while ip rule del "$@" 2>/dev/null; do :; done
  ip rule add "$@" 2>/dev/null || true
}

apply_dns() {
  ensure_wifi

  /system/bin/setprop net.dns1 "$DNS1" 2>/dev/null || true
  /system/bin/setprop net.dns2 "$DNS2" 2>/dev/null || true
  /system/bin/setprop net.wlan0.dns1 "$DNS1" 2>/dev/null || true
  /system/bin/setprop net.wlan0.dns2 "$DNS2" 2>/dev/null || true
  if [ $((PASS % SETTINGS_EVERY)) -eq 0 ]; then
    /system/bin/settings put global private_dns_mode off >/dev/null 2>&1
  fi

  iptables -t nat -C OUTPUT -p udp --dport 53 -j DNAT --to-destination "${DNS1}:53" >/dev/null 2>&1 \
    || iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination "${DNS1}:53" >/dev/null 2>&1 || true
  iptables -t nat -C OUTPUT -p tcp --dport 53 -j DNAT --to-destination "${DNS1}:53" >/dev/null 2>&1 \
    || iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination "${DNS1}:53" >/dev/null 2>&1 || true

  wlan_has_ip || { LAST_GW=""; return 0; }

  gw="$(ip route show table main 2>/dev/null | awk '/^default/ && /wlan0/ {print $3; exit}')"
  [ -n "$gw" ] || gw="$(/system/bin/getprop dhcp.wlan0.gateway 2>/dev/null)"
  case "$gw" in
    ""|"0.0.0.0"|"null") gw="" ;;
  esac
  [ -n "$gw" ] || gw="$(ip route show table all 2>/dev/null | awk '/default/ && /wlan0/ { for (i=1;i<=NF;i++) if ($i=="via") { print $(i+1); exit } }')"
  [ -n "$gw" ] || return 0

  # dumpsys is heavy: ask only when the gateway changed or every 10th pass
  if [ "$gw" != "$LAST_GW" ] || [ $((PASS % 10)) -eq 0 ]; then
    def="$(dumpsys connectivity 2>/dev/null | awk '/Active default network:/{print $4; exit}')"
    case "$def" in
      *[!0-9]*|"") def="" ;;
    esac
  else
    def="$LAST_DEF"
  fi
  # the routing tables are rebuilt only when something changed (and once a minute)
  if [ "$gw" = "$LAST_GW" ] && [ "$def" = "$LAST_DEF" ] && [ $((PASS % 20)) -ne 0 ]; then
    return 0
  fi

  # Keep every link route (wlan0 + eth0 car LAN) so table 100 does not blackhole ADB.
  ip -4 route show table main scope link 2>/dev/null | while read -r line; do
    [ -n "$line" ] || continue
    ip route replace $line table 100 2>/dev/null || true
    ip route replace $line table wlan0 2>/dev/null || true
    nid=$NID_LO
    while [ "$nid" -le "$NID_HI" ]; do
      ip route replace $line table "$nid" 2>/dev/null || true
      nid=$((nid + 1))
    done
  done

  ip route replace default via "$gw" dev wlan0 2>/dev/null || true
  ip route replace default via "$gw" dev wlan0 table 100 2>/dev/null || true
  ip route replace default via "$gw" dev wlan0 table wlan0 2>/dev/null || true

  nid=$NID_LO
  while [ "$nid" -le "$NID_HI" ]; do
    ip route replace default via "$gw" dev wlan0 table "$nid" 2>/dev/null || true
    hx=$(printf "%x" "$nid")
    hx2=$(printf "%x" $((65536 + nid)))
    set_rule pref 18800 from all fwmark "0x${hx}/0x1ffff" iif lo lookup "$nid"
    set_rule pref 12800 from all fwmark "0x${hx2}/0x1ffff" iif lo lookup "$nid"
    nid=$((nid + 1))
  done

  if [ -n "$def" ]; then
    ndc network default set "$def" >/dev/null 2>&1 || true
    ndc network route add "$def" wlan0 0.0.0.0/0 "$gw" >/dev/null 2>&1 || true
  fi

  state="dns=${DNS1}/${DNS2} gw=${gw} net=${def:-?}"
  if [ "$state" != "$LAST_STATE" ]; then
    logd "ok ${state}"
    LAST_STATE="$state"
  fi
  LAST_GW="$gw"
  LAST_DEF="$def"
}

if [ "$1" = "once" ]; then
  apply_dns
  exit 0
fi

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  old="$(tr -cd '0-9' <"$LOCK_DIR/pid" 2>/dev/null)"
  if [ -n "$old" ] && [ -d "/proc/$old" ]; then
    exit 0
  fi
  rm -rf "$LOCK_DIR" 2>/dev/null || true
  mkdir "$LOCK_DIR" 2>/dev/null || exit 0
fi
echo "$$" >"$LOCK_DIR/pid" 2>/dev/null || true

logd "daemon start pid=$$"
while true; do
  apply_dns
  PASS=$((PASS + 1))
  sleep 3
done
