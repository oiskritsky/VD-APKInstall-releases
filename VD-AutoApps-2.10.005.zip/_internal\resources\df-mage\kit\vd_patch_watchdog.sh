#!/system/bin/sh
# VD Auto Apps (DF Mage): keep the cdf_watchdog golden copies + hash whitelist in step
# with the /vendor files the program writes, adds or restores.
# Source of truth: resources/df-mage/kit in the program's repository.
#
#   sh vd_patch_watchdog.sh FILE...          refresh the golden copy + hash of each FILE
#   sh vd_patch_watchdog.sh --remove FILE... drop each FILE from the whitelist (it was ours
#                                            and is gone) together with its golden copy
#
# A missing whitelist is fine (nothing to keep in step): the script says so and exits 0.

WL="/data/local/tmp/.cdf_watchdog.wl"

hash_of() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v toybox >/dev/null 2>&1; then
    toybox sha256sum "$1" | awk '{print $1}'
  fi
}

drop_entry() {
  [ -f "$WL" ] || return 0
  grep -v "^$1:" "$WL" >"${WL}.new" 2>/dev/null || : >"${WL}.new"
  mv "${WL}.new" "$WL"
  chmod 644 "$WL" 2>/dev/null || true
}

refresh() {
  target="$1"
  [ -f "$target" ] || { echo "missing $target"; return 0; }
  DAT="/data/local/tmp/.$(basename "$target").dat"
  cat "$target" >"$DAT"
  chmod 644 "$DAT" 2>/dev/null || true
  HASH="$(hash_of "$target")"
  if [ -n "$HASH" ] && [ -f "$WL" ]; then
    drop_entry "$target"
    echo "$target:$HASH" >>"$WL"
    echo "watchdog hash updated: $target $HASH"
  else
    echo "watchdog hash skip ($target wl=$WL hash=$HASH)"
  fi
  echo "watchdog dat updated: $DAT"
}

remove() {
  target="$1"
  drop_entry "$target"
  rm -f "/data/local/tmp/.$(basename "$target").dat" 2>/dev/null || true
  echo "watchdog entry removed: $target"
}

mode=refresh
if [ "$1" = "--remove" ]; then
  mode=remove
  shift
fi
[ $# -gt 0 ] || { echo "usage: vd_patch_watchdog.sh [--remove] FILE..."; exit 2; }
for f in "$@"; do
  "$mode" "$f"
done
exit 0
