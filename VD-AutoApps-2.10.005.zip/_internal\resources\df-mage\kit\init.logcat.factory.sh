#!/system/bin/sh

LOG_TAG="logcat"
LOG_NAME="${0}:"

logcat_pid=""
cp_pid=""

sdcard_path="/logcache"
mount | grep "/logcache ext4" > /dev/null

#while [ $? == 1   ]
#do
#    sleep 1
#    mount | grep "/logcache ext4"
#done

loge ()
{
  /system/bin/log -t $LOG_TAG -p e "$LOG_NAME $@"
}

logi ()
{
  /system/bin/log -t $LOG_TAG -p i "$LOG_NAME $@"
}

failed ()
{
  loge "$1: exit code $2"
  exit $2
}

start_logcat ()
{
    if [ ! -d "${sdcard_path}/log" ]; then
        /system/bin/mkdir ${sdcard_path}/log/
    fi
    #if [ ! -d "${sdcard_path}/log/pstore" ]; then
    #    /system/bin/mkdir ${sdcard_path}/log/pstore/
    #fi
    
    #if [ -f "/sys/fs/pstore/dmesg-ramoops-0" ]; then
	#     /system/bin/tar czf  ${sdcard_path}/log/pstore/$(ls -l /private/log/pstore/|grep "^-"|wc -l).tar.gz  sys/fs/pstore/
    #    rm /sys/fs/pstore/dmesg-ramoops-0
    #fi
  #/system/bin/mkdir ${sdcard_path}/log/
  /system/bin/logcat -b main -b system -b crash -f ${sdcard_path}/log/logcat.log -r2048 -n 50 -v threadtime &
  logcat_pid=$!
  logi "start_logcat: logcat pid = $logcat_pid"
}

kill_logcat ()
{
  logi "kill_logcat: pid = $logcat_pid"
  ## careful not to kill zero or null!
  kill -TERM $logcat_pid
  # this shell doesn't exit now -- wait returns for normal exit
}

# init does SIGTERM on ctl.stop for service
#trap "kill_logcat" TERM INT

start_logcat

#wait $cp_pid
#busybox sync
wait $logcat_pid

logi "logcat service stopped"

exit 0
