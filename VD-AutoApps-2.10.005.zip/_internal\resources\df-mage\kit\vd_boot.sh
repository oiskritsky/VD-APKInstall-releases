#!/system/bin/sh
# VD Auto Apps (DF Mage): boot chain for the OPT-IN persistent mode.
# Installed as /vendor/bin/vd_boot.sh and started (oneshot) by
# /vendor/etc/init/vd_autoload.rc. It is a NEW file: the firmware's own
# /vendor/bin/init.logcat.sh stays as shipped (older versions of the program replaced
# it; the program puts the factory file back on its next persistence run or removal).
#
# Source of truth: resources/df-mage/kit in the program's repository.
#
# Deliberately NOT done here any more:
#   * no `setenforce 0` at boot - the supervisor goes permissive only right before an
#     injection, so a unit whose hooks are fused (or not configured) stays enforcing;
#   * no `setprop persist.apk.sign.verify 0` - the installer opens the cert gate for its
#     own session and closes it again; re-opening it on every boot defeated that.
#
# Boot safe mode: a previous boot that ended abnormally (kernel panic, watchdog, hardware
# reset - per sys.boot.reason) counts; SAFE_AFTER of them in a row and the hooks are NOT
# started (the DNS daemon is not a hook and is not affected). `vd_load.sh reset` or a
# re-deploy from the program clears it.
#
# Never block on settings/sdcard here - that hangs the boot instance. The payload lives
# in /data/local/tmp/vd: after a data wipe it is gone, and the chain simply exits.

LOAD_BIN="/data/local/tmp/vd/files/vd_load.sh"
STATE_DIR="/data/local/tmp/vd/files/autostart"
LOCK_DIR="/data/local/tmp/vd_boot.lock"
LOG_OUT="/data/local/tmp/vd/files/vd_load.txt"
RESTART_SLEEP=8
SAFE_AFTER=2

logi() {
  /system/bin/log -t VDLOAD -p i "boot: $*" 2>/dev/null || true
}

is_pid_alive() {
  [ -n "$1" ] && [ -d "/proc/$1" ]
}

is_our_boot_pid() {
  is_pid_alive "$1" || return 1
  _cmd="$(tr '\000' ' ' <"/proc/$1/cmdline" 2>/dev/null)"
  case "$_cmd" in
    *vd_boot.sh*) return 0 ;;
  esac
  return 1
}

acquire_lock() {
  if mkdir "$LOCK_DIR" 2>/dev/null; then
    echo "$$" >"$LOCK_DIR/pid" 2>/dev/null || true
    return 0
  fi
  old_pid="$(tr -cd '0-9' <"$LOCK_DIR/pid" 2>/dev/null)"
  if [ -n "$old_pid" ] && is_our_boot_pid "$old_pid"; then
    return 1
  fi
  rm -rf "$LOCK_DIR" 2>/dev/null || true
  mkdir "$LOCK_DIR" 2>/dev/null || return 1
  echo "$$" >"$LOCK_DIR/pid" 2>/dev/null || true
  return 0
}

if ! acquire_lock; then
  logi "already running pid=$(tr -cd '0-9' <"$LOCK_DIR/pid" 2>/dev/null), exit"
  exit 0
fi
trap 'rm -rf "$LOCK_DIR" 2>/dev/null; exit 0' INT TERM

while [ "$(/system/bin/getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

# /data is mounted once the boot completed; a short grace for slow storage only
wait_n=0
while [ ! -f "$LOAD_BIN" ] && [ "$wait_n" -lt 15 ]; do
  sleep 2
  wait_n=$((wait_n + 1))
done
if [ ! -f "$LOAD_BIN" ]; then
  logi "no hook payload in /data (wiped or never deployed) - nothing to start"
  rm -rf "$LOCK_DIR" 2>/dev/null
  exit 0
fi
mkdir -p "$STATE_DIR" 2>/dev/null || true

# ------------------------------------------------------------ boot safe mode
reason="$(/system/bin/getprop sys.boot.reason) $(/system/bin/getprop ro.boot.bootreason)"
case "$reason" in
  *panic* | *watchdog* | *wdt* | *hw_reset* | *oops* | *crash* | *abnormal*) abnormal=1 ;;
  *) abnormal=0 ;;
esac
n="$(tr -cd '0-9' <"$STATE_DIR/boot_abnormal" 2>/dev/null)"
n="${n:-0}"
if [ "$abnormal" -eq 1 ]; then
  n=$((n + 1))
else
  n=0
fi
echo "$n" >"$STATE_DIR/boot_abnormal" 2>/dev/null || true
if [ "$n" -ge "$SAFE_AFTER" ] && [ ! -f "$STATE_DIR/boot_safe_mode" ]; then
  echo "$n abnormal boots in a row (last reason: $reason)" >"$STATE_DIR/boot_safe_mode" 2>/dev/null
fi
if [ -f "$STATE_DIR/boot_safe_mode" ]; then
  logi "SAFE MODE: hooks not started ($(head -n 1 "$STATE_DIR/boot_safe_mode" 2>/dev/null)); re-deploy the hooks or run vd_load.sh reset"
  rm -rf "$LOCK_DIR" 2>/dev/null
  exit 0
fi

# system_server / SettingsProvider are not ready at the boot_completed edge
sleep 8
chmod 755 "$LOAD_BIN" 2>/dev/null || true

logi "loop start LOAD_BIN=$LOAD_BIN"
: >"$LOG_OUT" 2>/dev/null || true

while true; do
  /system/bin/sh "$LOAD_BIN" >>"$LOG_OUT" 2>&1
  rc=$?
  logi "supervisor exited rc=$rc, restart in ${RESTART_SLEEP}s"
  [ -f "$LOAD_BIN" ] || { logi "payload removed - boot chain ends"; break; }
  sleep "$RESTART_SLEEP"
done
rm -rf "$LOCK_DIR" 2>/dev/null
exit 0
